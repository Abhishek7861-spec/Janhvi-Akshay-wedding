JANHAVI & AKSHAY — DIGITAL WEDDING INVITATION

Included:
- index.html: mobile-friendly emerald-green and gold invitation website
- Family details from the provided invitation image
- Ceremony dates and the supplied engagement/wedding timings, shown once in the Wedding Festivities section
- Google Maps directions and a QR code that points to the venue search
- WhatsApp RSVP form
- Opening double-leaf animation

Before publishing:
1. Open index.html in a browser to preview.
2. For music, add a licensed audio file named wedding-music.mp3 beside index.html. The website cannot include music unless that file is supplied.
3. The QR code currently uses an external QR image service. Test it after publishing and before printing.
4. Haldi and Mehendi timings/locations were not present in the reference image; add them only once confirmed.
5. The RSVP form opens WhatsApp and does not store guest responses.

Free publishing option:
1. Create a public GitHub repository.
2. Upload index.html and optional wedding-music.mp3.
3. Open Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
4. GitHub Pages will show the published website URL when deployment completes.

Venue:
Shrinath Palace, Old Akluj Bypass Road, Pandharpur, Maharashtra 413304
